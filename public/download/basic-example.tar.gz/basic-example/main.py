import numpy as np

a = np.arange(15).reshape(3,5)

print(a)
print(type(a))
